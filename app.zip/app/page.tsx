"use client";

import { useState } from "react";
import Header from "@/components/Header";
import Hero from "@/components/Hero";
import AssistantCard from "@/components/AssistantCard";
import MockResultCard from "@/components/MockResultCard";
import FeatureCards from "@/components/FeatureCards";
import FutureSections from "@/components/FutureSections";

export default function Home() {
  const [showResult, setShowResult] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setShowResult(true);
  };

  return (
    <div className="min-h-screen bg-canvas text-ink font-sans">
      <Header />

      <main className="max-w-[1200px] mx-auto px-6 py-12 md:py-24">
        <Hero />
        
        <AssistantCard onSubmit={handleSubmit} />

        {showResult && (
          <MockResultCard onClose={() => setShowResult(false)} />
        )}

        <FeatureCards />
        <FutureSections />
      </main>
    </div>
  );
}
